import React from 'react';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import NavBar from './components/Navbar';
import MiddleSection from './components/MiddleSection';
import Footer from './components/Footer';
import Cart from './components/Cart'; 
import LoginPage from './components/LoginPage'; 
import GenericPage  from './components/GenericPage';



function App() {
  return (
    <Router>
      <div className="App">
        <NavBar />
        
        {/* Routing Section For Pages */}
        <Routes>
          <Route path="/" element={<MiddleSection />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/genericpage" element={<GenericPage />} />
          <Route path="/Cart" element={<Cart />} />
          

        </Routes>
        
        <Footer />
      </div>
       
    </Router>
   
  );
}

export default App;