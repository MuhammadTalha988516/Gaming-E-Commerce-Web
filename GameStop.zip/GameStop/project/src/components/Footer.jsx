import React from 'react';
import '../styles/Footer.css';


function Footer() {
  return (
    <footer className="footer" id="footer-section"> 
      <div className="footer-content">
        <div className="subscribe">
          <h4>Subscribe to our emails</h4>
          <form className="subscribe-form">
            <input type="email" placeholder="Email" required />
            <button type="submit">→</button>
          </form>
        </div>

        
        <div className="social-icons">
          <a href="https://www.facebook.com" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-facebook"></i>
          </a>
          <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-linkedin"></i>
          </a>
          <a href="https://www.twitter.com" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="https://www.youtube.com" target="_blank" rel="noopener noreferrer">
            <i className="fab fa-youtube"></i>
          </a>
        </div>
      </div>

      <div className="footer-bottom">
        <p>© 2024, GameStop Pakistan Developed by BCE FA22</p>
      </div>
    </footer>
  );
}

export default Footer;
