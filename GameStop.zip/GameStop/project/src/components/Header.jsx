import React from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation
import '../styles/Header.css';

function Header() {
  return (
    <div className="header">
      <img src="img1.JPG" alt="Logo" />
      <a href="/">Home</a>
      <div className="dropdown">
        <a href="#" className="dropbtn">Shop</a>
        <div className="dropdown-content">
          <a href="/">Playstation</a>
          <a href="/">Xbox</a>
          <a href="/">Nintendo</a>
        </div>
      </div>
      <div className="dropdown">
        <a href="#" className="dropbtn">Brands</a>
        <div className="dropdown-content">
          <a href="/">Logitech</a>
          <a href="/">Razer</a>
          <a href="/">Apple</a>
        </div>
      </div>
      <a href="/">Contact Us</a>

      {/* Replacing User Button with Login Button */}
      <Link to="/login">
        <button className="btn btn-outline-primary d-flex align-items-center">
          <i className="bi bi-person me-2"></i> Login
        </button>
      </Link>

      <button className="btn btn-outline-success d-flex align-items-center">
        <i className="bi bi-cart me-2"></i> Cart
      </button>
    </div>
  );
}

export default Header;
