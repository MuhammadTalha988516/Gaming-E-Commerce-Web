import React, { useState } from "react";
import { Router } from "react-router-dom";
import imag2 from '../assets/img3.JPG';
import '../styles/BuyPage.css';


function BuyPage() {
  const [quantity, setQuantity] = useState(1);
  const [paymentMethod, setPaymentMethod] = useState("credit-card");

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Order placed: ${quantity} item(s) using ${paymentMethod}`);
  };

  return (
    <div>
         <img src={imag2} alt="Image 1" />
      <h1>Buy Page</h1>
      <form onSubmit={handleSubmit}>
        <label>
          Quantity:
          <input
            type="number"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value)}
            min="1"
          />
        </label><br></br>
        <br />
        <label>
          Payment Method:
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
          >
            <option value="credit-card">Credit Card</option>
            <option value="paypal">PayPal</option>
            <option value="cod">Cash on Delivery</option>
          </select>
        </label><br></br>
        <br />
        <button type="submit" id="btn">Place Order</button>
      </form>
    </div>
  );
}

export default BuyPage;
