import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/MiddleSection.css';

import imag1 from '../assets/imag2.png';
import imag2 from '../assets/img14.JPG';
import imag3 from '../assets/img1.JPG';
import imag4 from '../assets/img3.JPG';
import imag5 from '../assets/img4.JPG';
import imag6 from '../assets/img5.JPG';
import imag7 from '../assets/img8.JPG';
import imag8 from '../assets/img16con.jpeg';
import imag9 from '../assets/img17.jpeg';
import imag10 from '../assets/img18.jpg';
import imag11 from '../assets/img19.jpg';
import imag12 from '../assets/img20.jpg';
import imag13 from '../assets/img21.jpg';
import imag14 from '../assets/img22.jpg';
import imag15 from '../assets/img23.jpeg';
import imag16 from '../assets/img24.jpg';
import imag18 from '../assets/img27.jpg';
import imag19 from '../assets/img28.jpg';
import imag20 from '../assets/img29.jpg';
import imag21 from '../assets/img30.jpeg';

function MiddleSection() {
  const navigate = useNavigate();

  const [cartItems, setCartItems] = useState([]);
  const [animationTrigger, setAnimationTrigger] = useState(false);

  const [currentSlideIndexPC, setCurrentSlideIndexPC] = useState(0);
  const [currentSlideIndexCons, setCurrentSlideIndexCons] = useState(0);
  const [currentSlideIndexPS, setCurrentSlideIndexPS] = useState(0);

  const pc = [
    { image: imag9, text: 'Tom Clancy Rainbow Six Siege', price: 49.99 },
    { image: imag10, text: 'Grand Theft Auto 5', price: 59.99 },
    { image: imag14, text: 'Tekken 7', price: 39.99 },
    { image: imag15, text: 'Tekken 8', price: 80.0 },
    { image: imag21, text: 'Forza Horizon 5', price: 87.35 },
  ];
  const cons = [
    { image: imag3, text: 'PS5 Console Bundle', price: 499.99 },
    { image: imag8, text: 'PS5 Controller (WHITE)', price: 69.99 },
    { image: imag12, text: 'Xbox One Controller', price: 45.99 },
    { image: imag13, text: 'Xbox One', price: 39.99 },
    { image: imag19, text: 'PS4 PRO 1TB', price: 399.99 },
  ];
  const ps = [
    { image: imag5, text: 'Sonic X Shadow Generations PS5', price: 49.99 },
    { image: imag7, text: 'FIFA 2024 PS5', price: 69.99 },
    { image: imag2, text: 'FI-24 PS5', price: 45.99 },
    { image: imag16, text: 'Call Of Duty Modern Warfare 3', price: 59.99 },
    { image: imag18, text: 'God Of War', price: 79.99 },
    // { image: imag20, text: 'Hitman 3', price: 89.99 },
  ];

  const handleAddToCartClick = (product) => {
    // Get current cart items from localStorage
    const existingCart = JSON.parse(localStorage.getItem('cartItems')) || [];
    
    // Add the new item to the cart
    const updatedCart = [...existingCart, product];
    
    // Save updated cart back to localStorage
    localStorage.setItem('cartItems', JSON.stringify(updatedCart));
    
    setAnimationTrigger(true);
    setTimeout(() => setAnimationTrigger(false), 1000);
  };

  // const handleBuyClick = (product) => {
  //   navigate('/genericpage', {
  //     state: {
  //       image: { src: product.image, alt: product.text },
  //       name: product.text,
  //       price: product.price,
  //     },
  //   });
  // };

  const handleBuyClick = (product) => {
    // Assuming you're gathering multiple products in the cart
    const selectedProducts = [product];  // You can add more products as needed
  
    navigate('/genericpage', {
      state: { products: selectedProducts },  // Pass the products array
    });
  };
  

  const getImagesBatch = (array, startIndex) =>
    array.slice(startIndex * 4, (startIndex + 1) * 4);

  const handleNextSlide = (setSlideIndex, arrayLength) => {
    setSlideIndex((prevIndex) => ((prevIndex + 1) * 4 < arrayLength ? prevIndex + 1 : 0));
  };

  return (
    <div className="middle-sec">
      <img src={imag1} className="img-responsive" alt="Main Image" />

      {/* Cart Animation */}
      <div className={`cart-animation ${animationTrigger ? 'active' : ''}`}>
        <span>Item Added to Cart!</span>
      </div>

      {/* PC Games Section */}
      <div className="pc-games-section">
        <h1>PC Games</h1>
        <div className="slider-row">
          {getImagesBatch(pc, currentSlideIndexPC).map((product, index) => (
            <div key={index} className="image-slider-container">
              <div className="image-item">
                <img src={product.image} alt={product.text} />
                <p>{product.text}</p>
                <button id="buy" onClick={() => handleBuyClick(product)}>
                  Buy Now
                </button>
                <button id="addtocart" onClick={() => handleAddToCartClick(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => handleNextSlide(setCurrentSlideIndexPC, pc.length)}>
          Next
        </button>
      </div>

      {/* Gaming Consoles Section */}
      <div className="gaming-consoles-section">
        <h1>Gaming Consoles & Accessories</h1>
        <div className="slider-row">
          {getImagesBatch(cons, currentSlideIndexCons).map((product, index) => (
            <div key={index} className="image-slider-container">
              <div className="image-item">
                <img src={product.image} alt={product.text} />
                <p>{product.text}</p>
                <button id="buy" onClick={() => handleBuyClick(product)}>
                  Buy Now
                </button>
                <button id="addtocart" onClick={() => handleAddToCartClick(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => handleNextSlide(setCurrentSlideIndexCons, cons.length)}>
          Next
        </button>
      </div>

      {/* PS & Xbox Games Section */}
      <div className="ps-xbox-games-section">
        <h1>PS & Xbox Games</h1>
        <div className="slider-row">
          {getImagesBatch(ps, currentSlideIndexPS).map((product, index) => (
            <div key={index} className="image-slider-container">
              <div className="image-item">
                <img src={product.image} alt={product.text} />
                <p>{product.text}</p>
                <button id="buy" onClick={() => handleBuyClick(product)}>
                  Buy Now
                </button>
                <button id="addtocart" onClick={() => handleAddToCartClick(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => handleNextSlide(setCurrentSlideIndexPS, ps.length)}>
          Next
        </button>
      </div>
    </div>
  );
}

export default MiddleSection;
