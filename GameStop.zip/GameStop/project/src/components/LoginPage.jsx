import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; // Import the useNavigate hook
import '../styles/LoginPage.css';

export default function Login() {
    const [username, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate(); // Initialize the useNavigate hook

    const handleSubmit = (e) => {
        e.preventDefault(); // Prevent the default form submission behavior

        // Show alert before sending request
        alert("Submitted!");

        // Simulate successful login and route to home
        // You can skip the token setting if you don't need it
        // Optionally use the username, password for something else

        // Redirect to the home page after submission
        navigate('/'); // Redirect to the home page
    };

    return (
        <div className="login-wrapper">
            <h1>Welcome Back</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    <p>Username</p>
                    <input
                        type="text"
                        onChange={(e) => setUserName(e.target.value)}
                        value={username}
                        required
                    />
                </label>
                <label>
                    <p>Password</p>
                    <input
                        type="password"
                        onChange={(e) => setPassword(e.target.value)}
                        value={password}
                        required
                    />
                </label>
                <div>
                    <button type="submit">Submit</button>
                </div>
            </form>
        </div>
    );
}
