import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Cart.css';

const Cart = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([]);

  // Load cart items from localStorage when the component mounts
  useEffect(() => {
    const storedCartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    setCartItems(storedCartItems);
  }, []);

  // Clear the cart
  const handleClearCart = () => {
    localStorage.removeItem('cartItems'); // Remove items from localStorage
    setCartItems([]); // Clear the cart state
  };

  // Handle clicking on "Order Now" for a specific item
  const handleCheckoutClick = (productIndex) => {
    // Get the selected product
    const selectedProduct = cartItems[productIndex];

    // Remove the selected product from the cart
    const updatedCart = cartItems.filter((_, index) => index !== productIndex);

    // Update localStorage and state
    localStorage.setItem('cartItems', JSON.stringify(updatedCart));
    setCartItems(updatedCart);

    // Navigate to the GenericPage
    navigate('/genericpage', {
      state: { products: [selectedProduct] }, // Pass the selected product as an array
    });
  };

  return (
    <div className="cart-container">
      <h1>Your Cart</h1>
      {cartItems.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div>
          <ul className="cart-items-list">
            {cartItems.map((item, index) => (
              <li key={index} className="cart-item-box">
                <img src={item.image} alt={item.text} className="cart-item-image" />
                <div className="cart-item-details">
                  <span className="cart-item-title">{item.text}</span>
                  <span className="cart-item-price">${item.price.toFixed(2)}</span>
                </div>
                <button
                  className="order-now-button"
                  onClick={() => handleCheckoutClick(index)}
                >
                  Order Now
                </button>
              </li>
            ))}
          </ul>
          <button className="clear-cart-button" onClick={handleClearCart}>
            Clear Cart
          </button>
        </div>
      )}
      <button className="continue-shopping-button" onClick={() => navigate('/')}>
        Continue Shopping
      </button>
    </div>
  );
};

export default Cart;
