import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import '../styles/GenericPage.css';

function GenericPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const { products } = location.state || {}; // Expecting products as an array

  const [quantities, setQuantities] = useState(products?.map(() => 1));
  const [paymentMethod, setPaymentMethod] = useState('');
  const deliveryInsurance = 35; // Flat delivery insurance fee

  // Validate state and handle missing data
  if (!products || products.length === 0) {
    return (
      <div className="no-data-container">
        <h1>No Data Found</h1>
        <button onClick={() => navigate('/')} className="back-button">
          Go Back
        </button>
      </div>
    );
  }

  // Calculate total cost dynamically
  const totalCost = products.reduce(
    (total, product, index) => total + product.price * quantities[index],
    0
  ) + deliveryInsurance;
  const vat = (totalCost * 0.19).toFixed(2);

  // Handle quantity change for each product
  const handleQuantityChange = (index, event) => {
    const newQuantities = [...quantities];
    newQuantities[index] = Math.max(1, parseInt(event.target.value, 10)); // Ensure positive quantity
    setQuantities(newQuantities);
  };

  // Handle payment submission
  const handlePayment = () => {
    if (!paymentMethod) {
      alert('Please select a payment method before proceeding.');
    } else {
      alert('Payment successfully submitted!');
      navigate('/'); // Redirect to home page after payment
    }
  };

  return (
    <div className="shopping-cart-container">
      <header className="shopping-cart-header">
        <h1>Your Shopping Cart</h1>
      </header>

      <main className="shopping-cart-main">
        <section className="product-details-section">
          {products.map((product, index) => (
            <div key={index} className="product-details">
              <img
                src={product.image}
                alt={product.image}
                className="product-image"
              />
              <div>
                <p><strong>{product.name}</strong></p>
                <p>Unit Price: ${product.price.toFixed(2)}</p>
                <label>
                  Quantity: 
                  <input
                    type="number"
                    className="quantity-input"
                    value={quantities[index]}
                    onChange={(event) => handleQuantityChange(index, event)}
                    min="1"
                  />
                </label>
              </div>
            </div>
          ))}
        </section>

        <aside className="order-summary">
          <h2>Order Summary</h2>
          {products.map((product, index) => (
            <p key={index}>Items Cost: ${(product.price * quantities[index]).toFixed(2)}</p>
          ))}
          <p>Delivery Insurance: ${deliveryInsurance}</p>
          <hr />
          <p>
            <strong>Total Purchase: ${totalCost.toFixed(2)}</strong>
          </p>
          <p>VAT (19%): ${vat} (included)</p>
        </aside>
      </main>

      <div className="payment-section">
        <section className="payment-details">
          <h2>Confirm Payment Details</h2>
          <label>
            IBAN:
            <input type="text" className="input-field" placeholder="Enter IBAN" />
          </label>
          <label>
            Account Holder’s Name:
            <input type="text" className="input-field" placeholder="Account Holder's Name" />
          </label>
          <label>
            <input type="checkbox" />
            Save my bank details for future purchases?
          </label>
        </section>

        <section className="payment-methods">
          <h2>Choose Payment Method</h2>
          <label>
            <input
              type="radio"
              name="payment-method"
              value="credit-card"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />
            Credit Card
          </label>
          <label>
            <input
              type="radio"
              name="payment-method"
              value="paypal"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />
            PayPal
          </label>
          <label>
            <input
              type="radio"
              name="payment-method"
              value="bank-account"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />
            Bank Account
          </label>
          <label>
            <input
              type="radio"
              name="payment-method"
              value="easypaisa-jazzcash"
              onChange={(e) => setPaymentMethod(e.target.value)}
            />
            EasyPaisa/Jazzcash
          </label>
        </section>
      </div>

      <button onClick={handlePayment} className="confirm_payment">
        Confirm Payment
      </button>
    </div>
  );
}

export default GenericPage;
