import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/Navbar.css';
import Dropdown from './Dropdown.jsx';
import imag17 from '../assets/img25.JPG';

function Navbar() {
  
  const navigate = useNavigate(); // Initialize the useNavigate hook


  const scrollToFooter = () => {
    const footer = document.getElementById('footer-section');
    if (footer) {
      footer.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToPCGames = () => {
    const pcGamesSection = document.querySelector('.pc-games-section');
    if (pcGamesSection) {
      const offset = -100; // Adjust this value to control how much higher the element appears
      const top = pcGamesSection.getBoundingClientRect().top + window.scrollY + offset;
  
      window.scrollTo({
        top: top,
        behavior: 'smooth',
      });
    }
  };
  
  const scrollToConsole = () => {
    const consoleSection = document.querySelector('.gaming-consoles-section');
    if (consoleSection) {
      const offset = -100; 
      const top = consoleSection.getBoundingClientRect().top + window.scrollY + offset;
  
      window.scrollTo({
        top: top,
        behavior: 'smooth',
      });
    }
  };
  
  const scrollToConsoleGames = () => {
    const consoleGamesSection = document.querySelector('.ps-xbox-games-section');
    if (consoleGamesSection) {
      const offset = 100; 
      const top = consoleGamesSection.getBoundingClientRect().top + window.scrollY + offset;
  
      window.scrollTo({
        top: top,
        behavior: 'smooth',
      });
    }
  };




  // Handle profile icon click to route to login page
  const handleProfileClick = () => {
    navigate('/login'); // Navigate to the login page
  };
  const handleCartClick = () => {
    navigate('/cart'); // Navigate to the cart page
  };

  return (
    <div className="header">
      <a href="/" className="logo-link">
        <img src={imag17} alt="Image 1" className="logo" />
      </a>

      <nav className="nav-links">
        <a href="/" className="nav-link">Home</a>
        <a href="#!" className="nav-link" onClick={scrollToPCGames}>PC Games</a>
        <a href="#!" className="nav-link" onClick={scrollToConsole}>Consoles and Accesories</a>
        <a href="#!" className="nav-link" onClick={scrollToConsoleGames}>Console Games</a>
        <a href="#!" className="nav-link" onClick={scrollToFooter}>Contact Us</a>
      </nav>

      <div className="icons">
        <div className="cart-icon">
          <i className="bi bi-cart" onClick={handleCartClick}></i>
        </div>

        <div className="user-icon" onClick={handleProfileClick}> {/* Add onClick here */}
          <i className="bi bi-person"></i>
        </div>
      </div>
    </div>
  );
}

export default Navbar;